package com.example.hotel.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.Repo.bookingRepo;
import com.example.hotel.models.booking;

@Service
public class bookingService {
	@Autowired
	bookingRepo brepo;
	
	public List<booking> listbooking (){
		return brepo.findAll();
	}

	public void saveb(booking bookings) {
		brepo.save(bookings);
	}

	public booking get(Integer bId) {
		return brepo.findById(bId).get();
	}

	public void delete(Integer bId) {
		brepo.deleteById(bId);
	}
}
