package com.example.hotel.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.Repo.UserRepo;
import com.example.hotel.models.User;

@Service
public class UserService {
	@Autowired
	UserRepo repo;
	
	public List<User> listUser(){
		return repo.findAll();
	}
	public Optional<User> listUser (Integer id){
		return repo.findById(id);
	}
	
	public void save(User user) {
		repo.save(user);
	}
	
	public User get(Integer id) {
		return repo.findById(id).get();
	}
	
	public void delete(Integer id) {
		repo.deleteById(id);
	}
}