package com.example.hotel.Controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.hotel.Repo.UserRepo;
import com.example.hotel.Service.bookingService;
import com.example.hotel.models.User;
import com.example.hotel.models.booking;

@Controller
@RequestMapping("/users")
public class bookingController {
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	bookingService bservice;
	
	@RequestMapping("/homepage")
    public String homepage() {
    	return "hotel/UDashboard";
    }
	
	@RequestMapping("/sbooking")
    public String savebooking(booking bookings, Principal p) {
        String name = p.getName();
        User user = this.userRepo.getUserByUserName(name);
        user.getBookings().add(bookings);
        bookings.setUser(user);    
        bservice.saveb(bookings);
        return "redirect:/users/homepage";		
    }
}
