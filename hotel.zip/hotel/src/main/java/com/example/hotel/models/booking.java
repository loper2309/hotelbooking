package com.example.hotel.models;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="Bookings")
public class booking {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bId;
	private String aDate;
	private String dDate;
	private String Acount;
	private String Ccount;
	
	@ManyToOne(cascade=CascadeType.MERGE)	
	@JsonIgnore
	private User user;

	public int getbId() {
		return bId;
	}

	public void setbId(int bId) {
		this.bId = bId;
	}

	public String getaDate() {
		return aDate;
	}

	public void setaDate(String aDate) {
		this.aDate = aDate;
	}

	public String getdDate() {
		return dDate;
	}

	public void setdDate(String dDate) {
		this.dDate = dDate;
	}

	public String getAcount() {
		return Acount;
	}

	public void setAcount(String acount) {
		this.Acount = acount;
	}

	public String getCcount() {
		return Ccount;
	}

	public void setCcount(String ccount) {
		this.Ccount = ccount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public booking(int bId, String aDate, String dDate, String acount, String ccount, User user) {
		super();
		this.bId = bId;
		this.aDate = aDate;
		this.dDate = dDate;
		this.Acount = acount;
		this.Ccount = ccount;
		this.user = user;
	}

	public booking() {
		super();
	}

	@Override
	public String toString() {
		return "booking [bId=" + bId + ", aDate=" + aDate + ", dDate=" + dDate + ", Acount=" + Acount + ", Ccount="
				+ Ccount + ", user=" + user + "]";
	}
	
	
	
}
